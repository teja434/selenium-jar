# Find the longest common prefix
Write a program that finds the longest common prefix of given strings.