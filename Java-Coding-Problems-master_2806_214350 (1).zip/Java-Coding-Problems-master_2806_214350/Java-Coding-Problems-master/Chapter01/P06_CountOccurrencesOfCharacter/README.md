# Count occurrences of a certain character
Write a program that counts occurrences of a certain character in a given string.