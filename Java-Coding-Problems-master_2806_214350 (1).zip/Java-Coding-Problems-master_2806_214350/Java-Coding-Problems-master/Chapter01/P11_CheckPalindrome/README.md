# Check if a string is a palindrome
Write a program that determines if the given string is palindrome or not.