# Count vowels and consonants
Write a program that counts the number of vowels and consonants in a given string.