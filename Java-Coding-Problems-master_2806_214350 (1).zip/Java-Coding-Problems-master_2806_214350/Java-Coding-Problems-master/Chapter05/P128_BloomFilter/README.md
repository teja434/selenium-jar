# Bloom Filter
Write a program that implements the Bloom Filter algorithm.
