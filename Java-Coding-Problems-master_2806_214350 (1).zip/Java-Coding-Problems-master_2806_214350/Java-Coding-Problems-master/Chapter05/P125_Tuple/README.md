# Tuple
Write a program that implements a Tuple data structure.
