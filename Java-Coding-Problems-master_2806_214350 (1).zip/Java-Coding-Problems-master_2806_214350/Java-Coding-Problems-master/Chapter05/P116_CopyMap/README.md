# Copying HashMap
Write a program that performs a shallow and deep copy of a **HashMap**.
