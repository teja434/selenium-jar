# Filling and setting an array
Write several examples for fill up an array and set all elements based on a generator function to compute each element.
