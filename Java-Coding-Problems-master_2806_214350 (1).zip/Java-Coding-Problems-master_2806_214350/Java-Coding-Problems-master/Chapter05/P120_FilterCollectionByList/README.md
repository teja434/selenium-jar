# Filtering a Collection by a List
Write several solutions for filtering a **Collection** by a **List**. Reveal the best way to do it.
