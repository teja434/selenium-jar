package modern.challenge;

public class MainApplication {

    public static void main(String[] args) {

        System.out.println("The root directory of this project is:\n"
                + Roots.getCurrentProjectRootDirectory());
    }
}
