package modern.challenge;

@FunctionalInterface
public interface Square {

    int calculate(int x);
}
