# LVTI and Streams
Write several snippets of code that exemplifies the usage of LVTI and Java Streams.
