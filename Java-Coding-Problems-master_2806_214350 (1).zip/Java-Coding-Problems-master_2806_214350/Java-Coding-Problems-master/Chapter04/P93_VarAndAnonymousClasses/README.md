# LVTI and anonymous classes
Write several snippets of code that exemplifies the usage of LVTI in anonymous classes.
