# LVTI and generic types, T
Write several snippets of code that exemplifies how LVTI can be used in combination with generic types.
