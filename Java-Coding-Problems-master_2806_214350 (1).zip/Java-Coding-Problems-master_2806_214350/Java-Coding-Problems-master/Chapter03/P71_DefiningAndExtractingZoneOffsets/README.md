# Defining/extracting zone offsets
Write a program that reveals different techniques for defining and extracting zone offsets.
