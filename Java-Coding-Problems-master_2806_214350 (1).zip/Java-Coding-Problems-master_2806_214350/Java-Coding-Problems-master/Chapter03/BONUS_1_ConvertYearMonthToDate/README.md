# Converting `Date` to `YearMonth`
Write a program that converts an `Date` to `YearMonth` and vice-versa. 
