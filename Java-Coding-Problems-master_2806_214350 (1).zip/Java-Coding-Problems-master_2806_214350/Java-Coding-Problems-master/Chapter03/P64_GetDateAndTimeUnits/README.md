# Get date and time units
Write a program that extracts from an object representing a date-time the date and time units (e.g., extract from **Date** the year, month, minute, etc).
