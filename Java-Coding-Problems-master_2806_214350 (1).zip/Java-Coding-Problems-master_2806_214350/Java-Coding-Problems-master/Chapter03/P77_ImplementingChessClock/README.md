# Implementing a chess Clock
Write a program that implement a chess **Clock**.
