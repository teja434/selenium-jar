package modern.challenge;

public class Main {

    public static void main(String[] args) {

        Point p = new Point(1.2, 33.4);
        
        System.out.println("X: " + p.getX());
        System.out.println("Y: " + p.getY());
    }
    
}
