# Immutable String
Explain why the **String** class is immutable.
