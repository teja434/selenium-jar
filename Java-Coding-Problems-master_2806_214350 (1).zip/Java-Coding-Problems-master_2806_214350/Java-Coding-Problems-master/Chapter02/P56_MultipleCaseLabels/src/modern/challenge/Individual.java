package modern.challenge;

public class Individual extends SportType{    
}
